# اسکیل اینستاگرام فارسی برای Claude

سیزده اسکیل Claude برای ساختن و اداره‌ی پیج اینستاگرام **فارسی**. رایگان، متن‌باز (MIT)، بدون ثبت‌نام، بدون کلید API، و بدون اتصال به حساب اینستاگرامت.

یکیش ریلزت رو از روی ۲۷ فرمول هوک می‌نویسه و قبل از اینکه یه برداشت هدر بدی، هوک رو امتیاز می‌ده. یکیش می‌ره و ریلزهایی که همین الان تو حوزه‌ت جواب می‌دن رو پیدا می‌کنه. یکیش کپشن می‌نویسه و دقیقاً نشون می‌ده فید قبل از «… بیشتر» چی نشون می‌ده. یکیش به پروفایلت از ۱۰۰ نمره می‌ده. یکیش هفته‌ت رو با تقویم شمسی برنامه می‌ریزه.

و یکیش **انسانی‌ساز فارسیه**: کلمه‌های بوی AI، زبون کتابی تو متنی که قراره گفته بشه، «ي/ك» عربی و نیم‌فاصله‌ی جاافتاده رو درست می‌کنه، و **هیچ‌وقت نیم‌فاصله رو خراب نمی‌کنه.**

**تا تو نگی، هیچی منتشر نمی‌شه.** این اسکیل‌ها می‌نویسن. تو منتشر می‌کنی.

> این بسته بازنویسی فارسی [instagram-agent-skill](https://github.com/Jakeschincariol/instagram-agent-skill) ساخته‌ی Jake Schincariol (MIT)ئه. ساختار، روش و صداقت نسخه‌ی اصلی مال اونه؛ فارسی‌سازی، ابزارهای فارسی و بخش‌های ایرانی رو [امید خاوری (OMID)](https://www.instagram.com/itsomid1.ai/) اضافه کرده.

## چرا یه نسخه‌ی فارسی؟

نسخه‌ی اصلی برای انگلیسی ساخته شده و رو متن فارسی دو تا مشکل جدی داره:

1. **انسانی‌سازش نیم‌فاصله رو پاک می‌کنه.** همه‌ی کاراکترهای «نامرئی» رو به‌عنوان ردپای ماشین حذف می‌کنه، و نیم‌فاصله (U+200C) هم یکی از اوناست. نتیجه:
   - «می‌سازی» ← «میسازی»
   - «کلمه‌ی» ← «کلمهی»
   - «خطرناک‌ترین» ← «خطرناکترین»
2. **ابزارهای امتیازدهی فارسی رو نمی‌شمرن.** فقط حروف لاتین رو کلمه حساب می‌کنن. یه هوک فارسی یازده‌کلمه‌ای برای امتیازدهِ اصلی «۱ کلمه، ۰٫۴ ثانیه»ئه و همیشه WEAK می‌گیره، هر چی هم که بگه.

این نسخه هر دو رو درست کرده، و بعد برای اینستاگرام فارسی بومی‌ش کرده:

- **کلمه‌شماری فارسی:** کلمه‌ی نیم‌فاصله‌دار یه کلمه‌ست. رقم فارسی (۰-۹) و جداکننده‌ی «٬» عددن. عددهای گفتاری («بیست میلیون») و کلمه‌های پولی («تومن») چیز مشخص حساب می‌شن.
- **۲۷ فرمول هوک با مثال ایرانی.** ۲۶ تای نسخه‌ی اصلی، به‌اضافه‌ی **«ببین چی می‌شه اگه…»**. هر فرمول هم هوک فارسی رو اسم‌گذاری می‌کنه، هم انگلیسی.
- **محاوره در برابر کتابی.** بزرگ‌ترین نشونه‌ی سناریوی ماشینی فارسی زبون نوشتاریه («می‌شود»، «را»، «می‌باشد») تو متنی که قراره بلند گفته بشه. ابزار تشخیص این نسبت رو می‌سنجه، و `humanize.py --spoken` تبدیلش می‌کنه.
- **فرهنگ کلمه‌های بوی AI فارسی:** «در دنیای امروز»، «شگفت‌انگیز»، «انقلابی»، «لذا»، «سلام دوستان»، «تو این ویدیو»، «امیدوارم مفید بوده باشه»…
- **ساختارهای لودهنده‌ی فارسی:** «این فقط یه X نیست، بلکه Y»، «نه‌تنها… بلکه…»، «تا آخر ببین»، «اسکرول نکن»…
- **کپشن فارسی:**
  - هشتگ فارسی شمرده می‌شه.
  - CTAهای فارسی شناخته می‌شن: «کلمه‌ی X رو کامنت کن»، «دایرکت بده»، «سیو کن».
  - «ي/ك» عربی که می‌تونه سرچ رو خراب کنه، علامت می‌خوره.
  - کلمه‌ی کامنتی که نیم‌فاصله داره و تایپش سخته، علامت می‌خوره.
- **ایران:**
  - سه سؤال همیشگی مخاطب ایرانی برای هر ریلز ابزار: از ایران کار می‌کنه؟ رایگانه؟ از کجا شروع کنم؟
  - تقویم شمسی، هفته از شنبه، ساعت تهران.
  - مناسبت‌ها و روزهای عزا.
  - راه دوم برای وقتی اینستاگرام ناپایداره.
  - نکته‌ی فیلترشکن برای ابزارهای تحقیق.

## نصب

به Claude بگو:

```
https://github.com/omidkhavari1708-pixel/instagram-agent-fa

این اسکیل رو نصب کن و بعد چک کن /insta-reel کار می‌کنه.
```

یا خودت، تو Claude Code:

```bash
git clone https://github.com/omidkhavari1708-pixel/instagram-agent-fa.git
cp -r instagram-agent-fa/skills/insta-* ~/.claude/skills/
```

ویندوز (PowerShell):

```powershell
git clone https://github.com/omidkhavari1708-pixel/instagram-agent-fa.git
Copy-Item -Recurse instagram-agent-fa\skills\insta-* $HOME\.claude\skills\
```

یا به‌صورت پلاگین:

```
/plugin marketplace add omidkhavari1708-pixel/instagram-agent-fa
/plugin install instagram-agent-fa
```

اسم‌ها با `insta-` شروع می‌شن تا با نسخه‌ی انگلیسی (`ig-`) قاطی نشن؛ اگه بخوای، هر دو رو کنار هم داشته باش.

**از ایران:** گیت‌هاب معمولاً بدون فیلترشکن باز می‌شه. اگه `git clone` گیر کرد، از پروکسی فیلترشکنت رد کن:
`git -c http.proxy=http://127.0.0.1:PORT clone …`

بعد ده دقیقه برای `templates/voice.md` وقت بذار. کپیش کن تو `~/.claude/instagram/voice.md` و پرش کن، یا سه تا از ریلزهای خودت رو به Claude بده و بگو «voice.md منو از روی این‌ها بنویس». همه‌ی اسکیل‌ها اینو می‌خونن.

## وصل کردن به پیجت

سه راه داری. هیچ‌کدوم رمز پیجت رو نمی‌خوان.

| راه | چی می‌بینه | برای کی |
| --- | --- | --- |
| **۱ · اسکرین‌شات و متن** | فقط چیزی که خودت می‌دی | همه؛ بدون هیچ دسترسی |
| **۲ · Claude in Chrome** | آمار، کامنت و دایرکت، تو کروم خودت که خودت توش لاگین کردی | پیشنهادی، از ایران هم کار می‌کنه |
| **۳ · API رسمی Meta** | آمار و دایرکت، فقط‌خواندنی؛ ارسال فقط با تأیید | حساب حرفه‌ای + اپ توسعه‌دهنده‌ی Meta (از ایران باز نمی‌شه) |

**راه ۱:**
- تو اپ گوشی روی هر ریلز بزن **View insights** و اسکرین‌شات بگیر. نمودار نگه‌داشت فقط تو اپه.
- بعد بفرست و بگو: «/insta-audit این‌ها رو بخون».

**راه ۲:**
1. [افزونه‌ی Claude in Chrome](https://chromewebstore.google.com/detail/claude/fcoeoabgfenejglbffodgkkbkcdhcgfn) رو نصب کن (نسخه‌ی ۱.۰.۳۶ به بالا). با همون حساب Claude Code وارد شو (پلن Pro یا Max).
2. Claude Code رو با `claude --chrome` باز کن. برای همیشه روشن موندنش: `/chrome` ← **Enabled by default**.
3. تو همون کروم خودت برو instagram.com و لاگین کن. رمز و کد تأیید رو همیشه خودت می‌زنی؛ Claude سر صفحه‌ی لاگین یا CAPTCHA می‌ایسته و از تو می‌خواد.
4. بگو: «با کروم برو تو اینستاگرامم و آمار ۹ تا ریلز آخرم رو با /insta-audit بخون». وقتی پرسید `Claude in Chrome wants to…`، برای instagram.com اجازه بده.

**از ایران:** اگه فیلترشکنت کل سیستم رو رد نمی‌کنه، یه پروفایل جدا از کروم با پروکسیش باز کن و افزونه رو تو همون پروفایل نصب کن:

```powershell
& "C:\Program Files\Google\Chrome\Application\chrome.exe" --user-data-dir="$env:LOCALAPPDATA\chrome-insta" --proxy-server=http://127.0.0.1:PORT
```

**راه ۳:** [`connect/ig_insights.py`](connect/ig_insights.py)
- توکن «Instagram API with Instagram Login» رو تو `~/.claude/instagram/.ig_token` بذار، بعد:
  - `python3 connect/ig_insights.py --check`
  - `python3 connect/ig_insights.py`
- خروجی تو `insights.md` نوشته می‌شه.
- هر ۵۰ روز یه بار `--refresh` بزن.
- ارسال دایرکت فقط با `--send … --text-file … --yes` ممکنه.

**پس گرفتن دسترسی:**
- **کروم:** افزونه رو از `chrome://extensions` بردار.
- **API:** اپ رو از تنظیمات اینستاگرام بردار (**Website permissions ← Apps and websites**).

## سیزده تا

| دستور | کارش |
| --- | --- |
| `/insta-reel` | یه ایده ← یه ریلز. سه هوک از [۲۷ فرمول](skills/insta-reel/hooks.json) با امتیاز، بعد سناریوی محاوره، متن روی صفحه و زمان‌بندی. |
| `/insta-viral` | می‌ره و پیدا می‌کنه چی تو حوزه‌ت جواب می‌ده؛ رتبه‌بندی با ضریب جهش نسبت به میانه‌ی خود هر حساب، اسم فرمول، فایل الگو. |
| `/insta-caption` | کپشن، با بررسی خودکار. ۱۲۵ کاراکتری که فید قبل از «بیشتر» نشون می‌ده رو نشونت می‌ده. |
| `/insta-carousel` | کاروسل. کاوری که ورق زدن رو می‌گیره، متن اسلایدها، و فایل‌های ۱۰۸۰×۱۳۵۰ راست‌به‌چپ. |
| `/insta-story` | ترتیب استوری روز، کدوم استیکر کجا، و قیف دایرکتی که با حرکت خود مخاطب شروع می‌شه. |
| `/insta-profile` | پروفایلت رو با [جدول ۱۲ بندی](skills/insta-profile/rubric.json) از ۱۰۰ نمره می‌ده و به ترتیب اولویت بازنویسی می‌کنه. |
| `/insta-plan` | هفته. چی، با چه فرمتی، کی (ساعت تهران، تقویم شمسی)، و ۱۰ حسابی که باید باهاشون تعامل کنی. |
| `/insta-human` | انسانی‌ساز فارسی و انگلیسی. دو تا اسکریپت که واقعاً اجرا می‌شن. |
| `/insta-comment` | کامنت زیر پست بقیه. نه نوع، بر اساس اینکه پست واقعاً چیه. هیچ‌وقت «عالی بود 🔥». |
| `/insta-reply` | کامنت‌های زیر پست خودت. دسته‌بندی به کلمه / مشتری / محتوا / سؤال / حمایت / نویز، بعد نوشتن به همین ترتیب. |
| `/insta-dm` | تحویل کلمه‌ی کامنت، اولین پیام، پیشنهاد همکاری، و دو پیگیری. فقط دو تا. |
| `/insta-repurpose` | یه ویدیو، پادکست یا مقاله‌ی بلند ← یه هفته ریلز و کاروسل که هر کدوم خودشون سرپان. |
| `/insta-audit` | کالبدشکافی چیزهایی که منتشر کردی. رتبه‌بندی با ضریب جهش و فرستادن به ازای ریچ، نه ویو. |

## پنج ابزاری که واقعاً اجرا می‌شن

بدون وابستگی (فقط پایتون استاندارد)، بدون اینترنت، هیچی آپلود نمی‌شه. رو سیستم خودت، رو متن خودت اجرا می‌شن.

```bash
python3 skills/insta-reel/hookscore.py --hook "ببین… سایتی که با AI ساختی، خطرناک‌ترین درش تو کدش نیست."
python3 skills/insta-reel/beats.py script.txt --target 40
python3 skills/insta-caption/caption.py caption.txt --keywords "سایت شخصی"
python3 skills/insta-human/humanize.py script.txt --spoken --report
python3 skills/insta-human/detect.py before.txt after.txt
python3 skills/insta-viral/swipe.py captured.tsv
```

نمونه:

```
HOOK RANKING
->  77.8 STRONG  ببین… سایتی که با AI ساختی، خطرناک‌ترین درش تو کدش نیست.
    63.1 OK      ببین چی می‌شه اگه دیگه برای ساخت ویدیو حتی به Google Flow ه...
    34.2 WEAK    سایت من نه سرور داره، نه هاست، نه اجاره‌ی سالانه.
     0.0 WEAK    سلام دوستان، امروز می‌خوام یه ابزار جدید بهتون معرفی کنم
        dealbreaker: مقدمه‌ی ویدیو («تو این ویدیو…»). پاکش کن و با خود نتیجه شروع کن.
        dealbreaker: سلام کردن. کسی برای سلام شنیدن تو فید نیومده.
```

## ریزنویس، که بخش صادقانه‌ست

**این اسکیل‌ها خودشون تو اینستاگرام چیزی منتشر نمی‌کنن.**
- هر اسکیل با یه بلوک آماده‌ی کپی تموم می‌شه که تو منتشرش می‌کنی.
- اگه از راه ۲ (Claude in Chrome) وصلی، Claude می‌تونه یه کامنت، جواب یا تغییر بایو رو برات بذاره. ولی فقط بعد از اینکه **همون متن دقیق** رو تأیید کردی، یکی‌یکی، با سرعت آدم.
- کامنت، فالو یا دایرکت خودکار و دسته‌جمعی خلاف [قوانین اینستاگرام](https://help.instagram.com/581066165581870)ه و حساب رو محدود می‌کنه. این بسته هیچ‌وقت انجامش نمی‌ده.

**هیچ‌وقت رمز پیجت رو به هیچ اسکیل، اسکریپت یا سرویسی نده.**

**`/insta-viral` می‌خونه، اسکرپ نمی‌کنه.** ده حساب، از هر کدوم ده‌دوازده ریلز، با سرعت آدم، با مرورگر خودت و با حضور خودت.

**امتیازها قاعده‌ی محلی‌ان، نه پیش‌بینی.**
- امتیازدهِ هوک نسخه‌ی اصلی روی ۷۴ هوک انگلیسی تست شده بود. تو جدا کردن هوک واقعی از هوک عمداً بد خوب بود (AUC ۰٫۸۳). تو جدا کردن موفق‌ها از ناموفق‌های یه سازنده تقریباً شیر یا خط بود (AUC ۰٫۵۶).
- **قاعده‌های فارسی هنوز روی یه مجموعه‌ی بزرگ فارسی اعتبارسنجی نشدن.** اگه هوک‌های فارسی واقعی با آمارشون داری و تست کردی، ترجیح می‌دم بدونم.
- به نمودار نگه‌داشت خودت بیشتر از این عددها اعتماد کن.

**ابزار تشخیص، GPTZero یا Originality یا Turnitin نیست.**
- به API هیچ‌کدوم وصل نمی‌شه و حکمشون رو تضمین نمی‌کنه.
- هر کی بهت «غیرقابل تشخیص» بفروشه، داره یه چیز دیگه می‌فروشه.

**هیچی ساخته نمی‌شه.** نه عدد، نه مشتری، نه نتیجه‌ای که به اسم تو بره. اگه پیش‌نویسی عددی لازم داره که ندادی، با `{{عدد تو}}` و یه علامت برمی‌گرده.

**عددهای پلتفرم کهنه می‌شن.** سقف هشتگ ۱۸ دسامبر ۲۰۲۵ از ۳۰ به ۵ رسید. اگه چیزی اینجا با کاری که اینستاگرام موقع خوندنت می‌کنه نمی‌خونه، حق با اینستاگرامه.

## تست

```bash
python3 -m unittest discover tests -v
```

۳۱ تست.
- دو تا باگ اصلی، یعنی پاک شدن نیم‌فاصله و نشمردن کلمه‌ی فارسی، اول از همه تست می‌شن.
- امتیاز هوک‌های انگلیسی دقیقاً با نسخه‌ی اصلی برابره.
- یه باگ هم از اجرای واقعی پیدا شد و درست شد: `detect.py` به کامنت ۱ تا ۳ جمله‌ای هیچ‌وقت PASS نمی‌داد.
- قانون‌های امنیتی اسکریپت اتصال هم تست می‌شن: بدون `--yes` چیزی نمی‌فرسته، و توکن تو خطاها لو نمی‌ره.

## فایل‌ها

```
skills/insta-reel/hooks.json         ۲۷ فرمول هوک: قالب، مثال فارسی، متن روی صفحه، کاربرد، دام، regex فارسی+انگلیسی
skills/insta-reel/hookscore.py       پنج معیار امتیاز هوک، فارسی و انگلیسی
skills/insta-reel/beats.py           سناریو ← زمان‌بندی، با کلمه‌شماری فارسی
skills/insta-caption/caption.py      پیش‌نمایش برش و بررسی کپشن فارسی
skills/insta-human/slop.json         فرهنگ دوزبانه: کلمه‌ها، عبارت‌ها، کتابی←محاوره، ساختارها، قانون نیم‌فاصله
skills/insta-human/humanize.py       پاک‌سازی، بدون دست زدن به نیم‌فاصله
skills/insta-human/detect.py         پنج معیار تشخیص؛ برای فارسی، محاوره در برابر کتابی
skills/insta-human/fatext.py         هسته‌ی متن فارسی (یه نسخه‌ی یکسان تو هر پوشه‌ای که ابزار داره)
skills/insta-viral/swipe.py          رتبه‌بندی با ضریب جهش و اسم‌گذاری فرمول
skills/insta-profile/rubric.json     جدول ۱۰۰ امتیازی پروفایل
templates/voice.md                   پروفایل صدای تو. اول اینو پر کن.
connect/ig_insights.py               راه ۳: آمار و دایرکت از API رسمی Meta، فقط‌خواندنی؛ ارسال فقط با --yes
```

## سازنده‌ها

- **نسخه‌ی اصلی:** Jake Schincariol · [instagram-agent-skill](https://github.com/Jakeschincariol/instagram-agent-skill) · MIT
- **نسخه‌ی فارسی:** امید خاوری · [OMID روی اینستاگرام](https://www.instagram.com/itsomid1.ai/). اونجا با AI چیزهای خلاقانه می‌سازیم و یاد می‌گیریم بعد از هر زمین خوردن دوباره شروع کنیم.

حالا تو چی می‌سازی؟

---

## English

**Persian Instagram agent skills for Claude.** A Persian adaptation of Jake Schincariol's [instagram-agent-skill](https://github.com/Jakeschincariol/instagram-agent-skill) (MIT): thirteen skills, renamed `insta-*`, with every instruction rewritten in Persian for Persian-speaking creators.

It fixes two problems the original has with Persian text:

1. **The humanizer deleted the Persian half-space (ZWNJ, U+200C).** It treated it as an invisible watermark character, which breaks the spelling of ordinary words. This version keeps ZWNJ and the bidi marks.
2. **The scorers counted only `[A-Za-z]`.** A Persian hook scored as "1 word, 0.4s". All tools now use a shared Persian-aware tokenizer (`fatext.py`) that handles half-space words, Persian digits, and spoken Persian numbers and money words.

It also adds:

- 27 hook formulas with Persian examples. The 27th is OMID's signature, "ببین چی می‌شه اگه…".
- A Persian slop lexicon, and a written-to-spoken Persian conversion (`--spoken`).
- Persian structural tells.
- A spoken-vs-written register check in `detect.py`.
- Persian caption checks.
- Iran-specific guidance: the Jalali calendar, Tehran time, access questions, and VPN notes.

English input still works, and English hook scores match the original exactly. There are 31 tests: `python3 -m unittest discover tests -v`.

**Connecting your account** (no password ever):
1. Paste screenshots or text.
2. [Claude in Chrome](https://code.claude.com/docs/en/chrome): run `claude --chrome`, then log in to instagram.com yourself. Claude reads insights, comments and DMs, and only posts the exact text you approve.
3. The official API: `connect/ig_insights.py`. You need a token for "Instagram API with Instagram Login" with `instagram_business_basic` and `instagram_business_manage_insights`, plus `instagram_business_manage_messages` for DMs. It is read-only; sending a DM needs `--yes`.

It never posts, never logs in, and never asks for a password. License: MIT, with both copyright holders listed.
